import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/app_state.dart';
import 'screens/splash_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/signup_screen.dart';
import 'screens/home_screen.dart';
import 'screens/guest_list_screen.dart';
import 'screens/budget_tracker_screen.dart';
import 'screens/vendor_list_screen.dart';
import 'screens/schedule_screen.dart';
import 'screens/todo_screen.dart';
import 'screens/gallery_screen.dart';
import 'screens/profile_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const WeddingPlannerApp());
}

class WeddingPlannerApp extends StatelessWidget {
  const WeddingPlannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState()..init(),
      child: MaterialApp(
        title: 'Wedding Planner',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF9C27B0)),
          useMaterial3: true,
        ),
        initialRoute: SplashScreen.routeName,
        routes: {
          SplashScreen.routeName: (_) => const SplashScreen(),
          LoginScreen.routeName: (_) => const LoginScreen(),
          SignupScreen.routeName: (_) => const SignupScreen(),
          HomeScreen.routeName: (_) => const HomeScreen(),
          GuestListScreen.routeName: (_) => const GuestListScreen(),
          BudgetTrackerScreen.routeName: (_) => const BudgetTrackerScreen(),
          VendorListScreen.routeName: (_) => const VendorListScreen(),
          ScheduleScreen.routeName: (_) => const ScheduleScreen(),
          TodoScreen.routeName: (_) => const TodoScreen(),
          GalleryScreen.routeName: (_) => const GalleryScreen(),
          ProfileScreen.routeName: (_) => const ProfileScreen(),
        },
      ),
    );
  }
}
