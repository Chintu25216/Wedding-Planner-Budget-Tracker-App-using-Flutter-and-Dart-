import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
  }

  Future<void> setString(String key, String value) async {
    await _prefs!.setString(key, value);
  }

  String? getString(String key) => _prefs!.getString(key);

  Future<void> setJson(String key, Object value) async {
    await setString(key, jsonEncode(value));
  }

  dynamic getJson(String key) {
    final s = getString(key);
    if (s == null || s.isEmpty) return null;
    return jsonDecode(s);
  }

  Future<void> remove(String key) async {
    await _prefs!.remove(key);
  }
}
