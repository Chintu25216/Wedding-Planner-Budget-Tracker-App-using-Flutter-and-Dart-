import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class TodoScreen extends StatefulWidget {
  static const routeName = '/todos';
  const TodoScreen({super.key});

  @override
  State<TodoScreen> createState() => _TodoScreenState();
}

class _TodoScreenState extends State<TodoScreen> {
  final _title = TextEditingController();

  @override
  void dispose() {
    _title.dispose();
    super.dispose();
  }

  Future<void> _addTodoDialog() async {
    _title.clear();
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add To-Do'),
        content: TextField(controller: _title, decoration: const InputDecoration(labelText: 'Title')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (_title.text.trim().isEmpty) return;
              await context.read<AppState>().addTodo(TodoItem(title: _title.text.trim()));
              if (!mounted) return;
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('To-Do List')),
      floatingActionButton: FloatingActionButton(onPressed: _addTodoDialog, child: const Icon(Icons.add_task)),
      body: Consumer<AppState>(builder: (context, state, _) {
        if (state.todos.isEmpty) return const Center(child: Text('No tasks yet. Tap + to add.'));
        return ListView.separated(
          itemCount: state.todos.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (context, i) {
            final t = state.todos[i];
            return Dismissible(
              key: ValueKey('${t.title}-$i'),
              background: Container(color: Colors.redAccent),
              onDismissed: (_) => state.removeTodo(i),
              child: CheckboxListTile(
                value: t.done,
                onChanged: (v) => state.toggleTodo(i, v ?? false),
                title: Text(t.title),
              ),
            );
          },
        );
      }),
    );
  }
}
