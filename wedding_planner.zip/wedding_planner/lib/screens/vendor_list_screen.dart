import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class VendorListScreen extends StatefulWidget {
  static const routeName = '/vendors';
  const VendorListScreen({super.key});

  @override
  State<VendorListScreen> createState() => _VendorListScreenState();
}

class _VendorListScreenState extends State<VendorListScreen> {
  final _name = TextEditingController();
  final _category = TextEditingController();
  final _phone = TextEditingController();
  final _notes = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    _category.dispose();
    _phone.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _addVendorDialog() async {
    _name.clear();
    _category.clear();
    _phone.clear();
    _notes.clear();
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add Vendor'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: _name, decoration: const InputDecoration(labelText: 'Name')),
              TextField(controller: _category, decoration: const InputDecoration(labelText: 'Category')),
              TextField(controller: _phone, decoration: const InputDecoration(labelText: 'Phone')),
              TextField(controller: _notes, decoration: const InputDecoration(labelText: 'Notes')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (_name.text.trim().isEmpty) return;
              await context.read<AppState>().addVendor(
                    Vendor(
                      name: _name.text.trim(),
                      category: _category.text.trim(),
                      phone: _phone.text.trim(),
                      notes: _notes.text.trim(),
                    ),
                  );
              if (!mounted) return;
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Vendors')),
      floatingActionButton: FloatingActionButton(
        onPressed: _addVendorDialog,
        child: const Icon(Icons.add_business),
      ),
      body: Consumer<AppState>(builder: (context, state, _) {
        if (state.vendors.isEmpty) return const Center(child: Text('No vendors yet. Tap + to add.'));
        return ListView.separated(
          itemCount: state.vendors.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (context, i) {
            final v = state.vendors[i];
            return Dismissible(
              key: ValueKey('${v.name}-$i'),
              background: Container(color: Colors.redAccent),
              onDismissed: (_) => state.removeVendor(i),
              child: ListTile(
                title: Text(v.name),
                subtitle: Text([v.category, v.phone].where((s) => s.isNotEmpty).join(' • ')),
                trailing: v.notes.isEmpty ? null : const Icon(Icons.note),
              ),
            );
          },
        );
      }),
    );
  }
}
