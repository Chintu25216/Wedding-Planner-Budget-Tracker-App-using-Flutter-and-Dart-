import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class ProfileScreen extends StatefulWidget {
  static const routeName = '/profile';
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _names = TextEditingController();
  final _date = TextEditingController();
  final _venue = TextEditingController();

  @override
  void initState() {
    super.initState();
    final p = context.read<AppState>().profile;
    _names.text = p.coupleNames;
    _date.text = p.date;
    _venue.text = p.venue;
  }

  @override
  void dispose() {
    _names.dispose();
    _date.dispose();
    _venue.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(context: context, initialDate: now, firstDate: DateTime(now.year - 1), lastDate: DateTime(now.year + 5));
    if (picked != null) {
      _date.text = '${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}';
    }
  }

  Future<void> _save() async {
    await context.read<AppState>().saveProfile(Profile(coupleNames: _names.text.trim(), date: _date.text.trim(), venue: _venue.text.trim()));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile saved')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _names, decoration: const InputDecoration(labelText: 'Couple Names')),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: TextField(controller: _date, decoration: const InputDecoration(labelText: 'Wedding Date'))),
                IconButton(onPressed: _pickDate, icon: const Icon(Icons.calendar_today))
              ],
            ),
            const SizedBox(height: 12),
            TextField(controller: _venue, decoration: const InputDecoration(labelText: 'Venue')),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Save')),
            ),
          ],
        ),
      ),
    );
  }
}
