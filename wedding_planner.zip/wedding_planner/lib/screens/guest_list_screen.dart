import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class GuestListScreen extends StatefulWidget {
  static const routeName = '/guests';
  const GuestListScreen({super.key});

  @override
  State<GuestListScreen> createState() => _GuestListScreenState();
}

class _GuestListScreenState extends State<GuestListScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _group = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _group.dispose();
    super.dispose();
  }

  Future<void> _addGuestDialog() async {
    _name.clear();
    _phone.clear();
    _group.clear();
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add Guest'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Name')),
            TextField(controller: _phone, decoration: const InputDecoration(labelText: 'Phone')),
            TextField(controller: _group, decoration: const InputDecoration(labelText: 'Group')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (_name.text.trim().isEmpty) return;
              await context.read<AppState>().addGuest(
                    Guest(name: _name.text.trim(), phone: _phone.text.trim(), group: _group.text.trim()),
                  );
              if (!mounted) return;
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Guest List')),
      floatingActionButton: FloatingActionButton(
        onPressed: _addGuestDialog,
        child: const Icon(Icons.person_add),
      ),
      body: Consumer<AppState>(
        builder: (context, state, _) {
          if (state.guests.isEmpty) {
            return const Center(child: Text('No guests yet. Tap + to add.'));
          }
          return ListView.separated(
            itemCount: state.guests.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final g = state.guests[i];
              return Dismissible(
                key: ValueKey('${g.name}-$i'),
                background: Container(color: Colors.redAccent),
                onDismissed: (_) => state.removeGuest(i),
                child: CheckboxListTile(
                  value: g.rsvp,
                  onChanged: (v) => state.toggleGuestRsvp(i, v ?? false),
                  title: Text(g.name),
                  subtitle: Text([g.group, g.phone].where((s) => s.isNotEmpty).join(' • ')),
                  secondary: const Icon(Icons.event_available),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
