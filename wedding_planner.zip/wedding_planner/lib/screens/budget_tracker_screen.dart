import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import 'package:intl/intl.dart';

class BudgetTrackerScreen extends StatefulWidget {
  static const routeName = '/budget';
  const BudgetTrackerScreen({super.key});

  @override
  State<BudgetTrackerScreen> createState() => _BudgetTrackerScreenState();
}

class _BudgetTrackerScreenState extends State<BudgetTrackerScreen> {
  final _name = TextEditingController();
  final _est = TextEditingController();
  final _act = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    _est.dispose();
    _act.dispose();
    super.dispose();
  }

  Future<void> _addOrEdit({int? index}) async {
    final state = context.read<AppState>();
    if (index != null) {
      final b = state.budget[index];
      _name.text = b.name;
      _est.text = b.estimated.toString();
      _act.text = b.actual.toString();
    } else {
      _name.clear();
      _est.clear();
      _act.clear();
    }
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(index == null ? 'Add Item' : 'Edit Item'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Name')),
            TextField(controller: _est, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Estimated')),
            TextField(controller: _act, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Actual')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final name = _name.text.trim();
              final est = double.tryParse(_est.text) ?? 0;
              final act = double.tryParse(_act.text) ?? 0;
              if (name.isEmpty) return;
              final item = BudgetItem(name: name, estimated: est, actual: act);
              if (index == null) {
                await state.addBudgetItem(item);
              } else {
                await state.updateBudgetItem(index, item);
              }
              if (!mounted) return;
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Budget Tracker')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addOrEdit(),
        child: const Icon(Icons.add),
      ),
      body: Consumer<AppState>(builder: (context, state, _) {
        final currency = NumberFormat.simpleCurrency();
        final est = state.totalEstimated;
        final act = state.totalActual;
        final progress = est == 0 ? 0.0 : (act / est).clamp(0.0, 1.0);
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Estimated: ${currency.format(est)}'),
                  Text('Actual: ${currency.format(act)}'),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(value: progress),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: state.budget.isEmpty
                  ? const Center(child: Text('No budget items yet. Tap + to add.'))
                  : ListView.separated(
                      itemCount: state.budget.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, i) {
                        final b = state.budget[i];
                        return Dismissible(
                          key: ValueKey('${b.name}-$i'),
                          background: Container(color: Colors.redAccent),
                          onDismissed: (_) => state.removeBudgetItem(i),
                          child: ListTile(
                            title: Text(b.name),
                            subtitle: Text('Est: ${currency.format(b.estimated)} • Act: ${currency.format(b.actual)}'),
                            trailing: IconButton(icon: const Icon(Icons.edit), onPressed: () => _addOrEdit(index: i)),
                          ),
                        );
                      },
                    ),
            )
          ],
        );
      }),
    );
  }
}
