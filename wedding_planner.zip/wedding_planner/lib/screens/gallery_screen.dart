import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class GalleryScreen extends StatefulWidget {
  static const routeName = '/gallery';
  const GalleryScreen({super.key});

  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  final _picker = ImagePicker();

  Future<void> _pick() async {
    final state = context.read<AppState>();
    final x = await _picker.pickMultiImage();
    if (x.isEmpty) return;
    for (final f in x) {
      await state.addGalleryItem(GalleryItem(path: f.path));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gallery')),
      floatingActionButton: FloatingActionButton(onPressed: _pick, child: const Icon(Icons.add_a_photo)),
      body: Consumer<AppState>(builder: (context, state, _) {
        if (state.gallery.isEmpty) return const Center(child: Text('No photos yet. Tap + to add.'));
        return GridView.builder(
          padding: const EdgeInsets.all(8),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 4, mainAxisSpacing: 4),
          itemCount: state.gallery.length,
          itemBuilder: (context, i) {
            final g = state.gallery[i];
            return GestureDetector(
              onLongPress: () => state.removeGalleryItem(i),
              child: kIsWeb
                  ? Container(color: Colors.grey.shade300, child: const Icon(Icons.image))
                  : Image.file(File(g.path), fit: BoxFit.cover),
            );
          },
        );
      }),
    );
  }
}
