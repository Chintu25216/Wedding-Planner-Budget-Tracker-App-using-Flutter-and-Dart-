import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import 'guest_list_screen.dart';
import 'budget_tracker_screen.dart';
import 'vendor_list_screen.dart';
import 'schedule_screen.dart';
import 'todo_screen.dart';
import 'gallery_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatelessWidget {
  static const routeName = '/home';
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tiles = [
      _Tile('Guest List', Icons.group, GuestListScreen.routeName),
      _Tile('Budget', Icons.attach_money, BudgetTrackerScreen.routeName),
      _Tile('Vendors', Icons.store, VendorListScreen.routeName),
      _Tile('Schedule', Icons.event, ScheduleScreen.routeName),
      _Tile('To-Do', Icons.check_circle, TodoScreen.routeName),
      _Tile('Gallery', Icons.photo_library, GalleryScreen.routeName),
      _Tile('Profile', Icons.person, ProfileScreen.routeName),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Wedding Planner'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await context.read<AppState>().logout();
              if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
            },
            tooltip: 'Logout',
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          children: [
            for (final t in tiles)
              InkWell(
                onTap: () => Navigator.pushNamed(context, t.route),
                child: Card(
                  elevation: 2,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(t.icon, size: 40, color: Theme.of(context).colorScheme.primary),
                      const SizedBox(height: 10),
                      Text(t.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _Tile {
  final String title;
  final IconData icon;
  final String route;
  _Tile(this.title, this.icon, this.route);
}
