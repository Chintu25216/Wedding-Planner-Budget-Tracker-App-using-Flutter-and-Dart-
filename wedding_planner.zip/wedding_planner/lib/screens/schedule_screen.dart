import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class ScheduleScreen extends StatefulWidget {
  static const routeName = '/schedule';
  const ScheduleScreen({super.key});

  @override
  State<ScheduleScreen> createState() => _ScheduleScreenState();
}

class _ScheduleScreenState extends State<ScheduleScreen> {
  final _title = TextEditingController();
  final _location = TextEditingController();
  final _notes = TextEditingController();
  DateTime _dateTime = DateTime.now();

  @override
  void dispose() {
    _title.dispose();
    _location.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _addScheduleDialog() async {
    _title.clear();
    _location.clear();
    _notes.clear();
    _dateTime = DateTime.now();
    await showDialog(
      context: context,
      builder: (_) => StatefulBuilder(builder: (context, setStateSB) {
        return AlertDialog(
          title: const Text('Add Schedule Item'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: _title, decoration: const InputDecoration(labelText: 'Title')),
                TextField(controller: _location, decoration: const InputDecoration(labelText: 'Location')),
                TextField(controller: _notes, decoration: const InputDecoration(labelText: 'Notes')),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: Text('Date: ${_dateTime.toLocal().toString().split('.').first}')),
                    IconButton(
                      icon: const Icon(Icons.calendar_today),
                      onPressed: () async {
                        final d = await showDatePicker(
                          context: context,
                          initialDate: _dateTime,
                          firstDate: DateTime(2020),
                          lastDate: DateTime(2100),
                        );
                        if (d != null) setStateSB(() => _dateTime = DateTime(d.year, d.month, d.day, _dateTime.hour, _dateTime.minute));
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.schedule),
                      onPressed: () async {
                        final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_dateTime));
                        if (t != null) setStateSB(() => _dateTime = DateTime(_dateTime.year, _dateTime.month, _dateTime.day, t.hour, t.minute));
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                if (_title.text.trim().isEmpty) return;
                final state = context.read<AppState>();
                final nav = Navigator.of(context);
                await state.addScheduleItem(
                  ScheduleItem(
                    title: _title.text.trim(),
                    dateTime: _dateTime,
                    location: _location.text.trim(),
                    notes: _notes.text.trim(),
                  ),
                );
                nav.pop();
              },
              child: const Text('Add'),
            ),
          ],
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Schedule')),
      floatingActionButton: FloatingActionButton(onPressed: _addScheduleDialog, child: const Icon(Icons.add)),
      body: Consumer<AppState>(builder: (context, state, _) {
        if (state.schedule.isEmpty) return const Center(child: Text('No schedule items yet. Tap + to add.'));
        return ListView.separated(
          itemCount: state.schedule.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (context, i) {
            final s = state.schedule[i];
            return Dismissible(
              key: ValueKey('${s.title}-${s.dateTime.toIso8601String()}-$i'),
              background: Container(color: Colors.redAccent),
              onDismissed: (_) => state.removeScheduleItem(i),
              child: ListTile(
                title: Text(s.title),
                subtitle: Text('${state.formatDate(s.dateTime)}${s.location.isNotEmpty ? ' • ${s.location}' : ''}'),
              ),
            );
          },
        );
      }),
    );
  }
}
