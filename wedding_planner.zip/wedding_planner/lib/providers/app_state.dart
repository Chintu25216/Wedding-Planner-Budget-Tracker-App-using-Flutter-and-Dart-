import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/storage_service.dart';

class Guest {
  String name;
  String phone;
  String group;
  bool rsvp;
  Guest({required this.name, this.phone = '', this.group = '', this.rsvp = false});
  Map<String, dynamic> toMap() => {
        'name': name,
        'phone': phone,
        'group': group,
        'rsvp': rsvp,
      };
  factory Guest.fromMap(Map<String, dynamic> m) => Guest(
        name: m['name'] ?? '',
        phone: m['phone'] ?? '',
        group: m['group'] ?? '',
        rsvp: m['rsvp'] ?? false,
      );
}

class BudgetItem {
  String name;
  double estimated;
  double actual;
  BudgetItem({required this.name, this.estimated = 0, this.actual = 0});
  Map<String, dynamic> toMap() => {
        'name': name,
        'estimated': estimated,
        'actual': actual,
      };
  factory BudgetItem.fromMap(Map<String, dynamic> m) => BudgetItem(
        name: m['name'] ?? '',
        estimated: (m['estimated'] ?? 0).toDouble(),
        actual: (m['actual'] ?? 0).toDouble(),
      );
}

class Vendor {
  String name;
  String category;
  String phone;
  String notes;
  Vendor({required this.name, this.category = '', this.phone = '', this.notes = ''});
  Map<String, dynamic> toMap() => {
        'name': name,
        'category': category,
        'phone': phone,
        'notes': notes,
      };
  factory Vendor.fromMap(Map<String, dynamic> m) => Vendor(
        name: m['name'] ?? '',
        category: m['category'] ?? '',
        phone: m['phone'] ?? '',
        notes: m['notes'] ?? '',
      );
}

class ScheduleItem {
  String title;
  DateTime dateTime;
  String location;
  String notes;
  ScheduleItem({required this.title, required this.dateTime, this.location = '', this.notes = ''});
  Map<String, dynamic> toMap() => {
        'title': title,
        'dateTime': dateTime.toIso8601String(),
        'location': location,
        'notes': notes,
      };
  factory ScheduleItem.fromMap(Map<String, dynamic> m) => ScheduleItem(
        title: m['title'] ?? '',
        dateTime: DateTime.tryParse(m['dateTime'] ?? '') ?? DateTime.now(),
        location: m['location'] ?? '',
        notes: m['notes'] ?? '',
      );
}

class TodoItem {
  String title;
  bool done;
  TodoItem({required this.title, this.done = false});
  Map<String, dynamic> toMap() => {
        'title': title,
        'done': done,
      };
  factory TodoItem.fromMap(Map<String, dynamic> m) => TodoItem(
        title: m['title'] ?? '',
        done: m['done'] ?? false,
      );
}

class GalleryItem {
  String path;
  DateTime addedAt;
  GalleryItem({required this.path, DateTime? addedAt}) : addedAt = addedAt ?? DateTime.now();
  Map<String, dynamic> toMap() => {
        'path': path,
        'addedAt': addedAt.toIso8601String(),
      };
  factory GalleryItem.fromMap(Map<String, dynamic> m) => GalleryItem(
        path: m['path'] ?? '',
        addedAt: DateTime.tryParse(m['addedAt'] ?? '') ?? DateTime.now(),
      );
}

class Profile {
  String coupleNames;
  String date; // formatted
  String venue;
  Profile({this.coupleNames = '', this.date = '', this.venue = ''});
  Map<String, dynamic> toMap() => {
        'coupleNames': coupleNames,
        'date': date,
        'venue': venue,
      };
  factory Profile.fromMap(Map<String, dynamic> m) => Profile(
        coupleNames: m['coupleNames'] ?? '',
        date: m['date'] ?? '',
        venue: m['venue'] ?? '',
      );
}

class AppState extends ChangeNotifier {
  static const _kUserKey = 'user';
  static const _kGuestsKey = 'guests';
  static const _kBudgetKey = 'budget';
  static const _kVendorsKey = 'vendors';
  static const _kScheduleKey = 'schedule';
  static const _kTodosKey = 'todos';
  static const _kGalleryKey = 'gallery';
  static const _kProfileKey = 'profile';

  final storage = StorageService();

  bool initialized = false;
  bool loggedIn = false;
  String email = '';

  List<Guest> guests = [];
  List<BudgetItem> budget = [];
  List<Vendor> vendors = [];
  List<ScheduleItem> schedule = [];
  List<TodoItem> todos = [];
  List<GalleryItem> gallery = [];
  Profile profile = Profile();

  Future<void> init() async {
    await storage.init();
    _loadAll();
  }

  void _loadAll() {
    final u = storage.getJson(_kUserKey);
    if (u is Map<String, dynamic>) {
      email = u['email'] ?? '';
      loggedIn = u['loggedIn'] ?? false;
    }
    guests = _readList(_kGuestsKey, (m) => Guest.fromMap(Map<String, dynamic>.from(m)));
    budget = _readList(_kBudgetKey, (m) => BudgetItem.fromMap(Map<String, dynamic>.from(m)));
    vendors = _readList(_kVendorsKey, (m) => Vendor.fromMap(Map<String, dynamic>.from(m)));
    schedule = _readList(_kScheduleKey, (m) => ScheduleItem.fromMap(Map<String, dynamic>.from(m)));
    todos = _readList(_kTodosKey, (m) => TodoItem.fromMap(Map<String, dynamic>.from(m)));
    gallery = _readList(_kGalleryKey, (m) => GalleryItem.fromMap(Map<String, dynamic>.from(m)));
    final p = storage.getJson(_kProfileKey);
    if (p is Map<String, dynamic>) profile = Profile.fromMap(p);
    initialized = true;
    notifyListeners();
  }

  List<T> _readList<T>(String key, T Function(dynamic) fromMap) {
    final raw = storage.getJson(key);
    if (raw is List) {
      return raw.map((e) => fromMap(e)).toList();
    }
    return <T>[];
  }

  Future<void> _saveList(String key, List items) async {
    await storage.setJson(key, items.map((e) => (e as dynamic).toMap()).toList());
    notifyListeners();
  }

  // Auth
  Future<bool> signup(String email, String password) async {
    await storage.setJson(_kUserKey, {
      'email': email,
      'password': base64.encode(utf8.encode(password)),
      'loggedIn': true,
    });
    this.email = email;
    loggedIn = true;
    notifyListeners();
    return true;
  }

  Future<bool> login(String email, String password) async {
    final u = storage.getJson(_kUserKey);
    if (u is Map<String, dynamic>) {
      final ok = u['email'] == email && u['password'] == base64.encode(utf8.encode(password));
      if (ok) {
        await storage.setJson(_kUserKey, {...u, 'loggedIn': true});
        this.email = email;
        loggedIn = true;
        notifyListeners();
        return true;
      }
    }
    return false;
  }

  Future<void> logout() async {
    final u = storage.getJson(_kUserKey);
    if (u is Map<String, dynamic>) {
      await storage.setJson(_kUserKey, {...u, 'loggedIn': false});
    }
    loggedIn = false;
    email = '';
    notifyListeners();
  }

  // Guests
  Future<void> addGuest(Guest g) async {
    guests.add(g);
    await _saveList(_kGuestsKey, guests);
  }

  Future<void> toggleGuestRsvp(int index, bool value) async {
    guests[index].rsvp = value;
    await _saveList(_kGuestsKey, guests);
  }

  Future<void> removeGuest(int index) async {
    guests.removeAt(index);
    await _saveList(_kGuestsKey, guests);
  }

  // Budget
  double get totalEstimated => budget.fold(0, (s, i) => s + i.estimated);
  double get totalActual => budget.fold(0, (s, i) => s + i.actual);

  Future<void> addBudgetItem(BudgetItem b) async {
    budget.add(b);
    await _saveList(_kBudgetKey, budget);
  }

  Future<void> updateBudgetItem(int index, BudgetItem b) async {
    budget[index] = b;
    await _saveList(_kBudgetKey, budget);
  }

  Future<void> removeBudgetItem(int index) async {
    budget.removeAt(index);
    await _saveList(_kBudgetKey, budget);
  }

  // Vendors
  Future<void> addVendor(Vendor v) async {
    vendors.add(v);
    await _saveList(_kVendorsKey, vendors);
  }

  Future<void> removeVendor(int index) async {
    vendors.removeAt(index);
    await _saveList(_kVendorsKey, vendors);
  }

  // Schedule
  Future<void> addScheduleItem(ScheduleItem s) async {
    schedule.add(s);
    schedule.sort((a, b) => a.dateTime.compareTo(b.dateTime));
    await _saveList(_kScheduleKey, schedule);
  }

  Future<void> removeScheduleItem(int index) async {
    schedule.removeAt(index);
    await _saveList(_kScheduleKey, schedule);
  }

  // Todos
  Future<void> addTodo(TodoItem t) async {
    todos.add(t);
    await _saveList(_kTodosKey, todos);
  }

  Future<void> toggleTodo(int index, bool value) async {
    todos[index].done = value;
    await _saveList(_kTodosKey, todos);
  }

  Future<void> removeTodo(int index) async {
    todos.removeAt(index);
    await _saveList(_kTodosKey, todos);
  }

  // Gallery
  Future<void> addGalleryItem(GalleryItem g) async {
    gallery.add(g);
    await _saveList(_kGalleryKey, gallery);
  }

  Future<void> removeGalleryItem(int index) async {
    gallery.removeAt(index);
    await _saveList(_kGalleryKey, gallery);
  }

  // Profile
  Future<void> saveProfile(Profile p) async {
    profile = p;
    await storage.setJson(_kProfileKey, p.toMap());
    notifyListeners();
  }

  String formatDate(DateTime dt) => DateFormat('MMM d, y – h:mm a').format(dt);
}
