import 'package:flutter_test/flutter_test.dart';
import 'package:wedding_planner/main.dart';

void main() {
  testWidgets('App builds without crashing', (tester) async {
    await tester.pumpWidget(const WeddingPlannerApp());
    // Splash renders first
    expect(find.byType(WeddingPlannerApp), findsOneWidget);
  });
}
