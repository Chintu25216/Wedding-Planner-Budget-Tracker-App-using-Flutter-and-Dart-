package com.example.wedding_planner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
